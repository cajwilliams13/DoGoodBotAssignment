import time
from math import pi

import matplotlib.pyplot as plt
import numpy as np
import roboticstoolbox as rtb
import swift
from models.Brick.Brick import Brick
from models.EStop.EStop import EStop
from models.Fence.Fence import Fence
from models.FireExtinguisher.FireExtinguisher import FireExtinguisher
from models.Gripper.Gripper import Gripper
from models.LinearUR3.LinearUR3 import LinearUR3
from models.Table.Table import Table
from models.WallScaffold.WallScaffold import WallScaffold
from scipy.spatial import ConvexHull
from spatialmath import SE3
from spatialmath.base import plotvol3


#https://github.com/petercorke/robotics-toolbox-python/wiki/Grippers
class Assignment1():
    def __init__(self):
        self._setup_models()
        pass
    def _setup_models(self):
        # 1. Setup the models
        # 1.1. Create the table which will be used as the reference frame for the rest of the objects
        self.table = Table(SE3(0,0,0))
        self.table_dimensions = self.table.get_dimensions()

        # 1.2. Create the linear ur3 with a pose relative to the table
        desired_linear_ur3_pose_relative_to_table = SE3(self.table_dimensions[0]/2,self.table_dimensions[1]/2,self.table_dimensions[2])
        linear_ur3_base_global_frame = self.table.convert_local_position_to_global(desired_linear_ur3_pose_relative_to_table)
        self.linear_ur3 = LinearUR3(linear_ur3_base_global_frame @ SE3.Rz(-90, 'deg'))

        # 1.3. Create the gripper (note because we are using attach we don't have to set the pose here)
        self.gripper = Gripper()
        self.linear_ur3.attach_gripper(self.gripper)
        self.gripper.open_fingers() # Ensure the gripper starts in the open position

        # 1.4. Create the estop, fire extinguisher and fence
        estop_pose = self.table.convert_local_position_to_global(SE3(self.table_dimensions[0] - 0.1, 0.1, self.table_dimensions[2]))
        self.estop = EStop(estop_pose)

        fire_extinguisher_pose = self.table.convert_local_position_to_global(SE3(self.table_dimensions[0] + 0.1, 0.1, 0))
        self.fire_extinguisher = FireExtinguisher(fire_extinguisher_pose)

        fence_pose_1 = SE3(0,0,0)
        fence_pose_2 = SE3(0,0,0) @ SE3.Rz(90, 'deg')
        self.fence_1 = Fence(fence_pose_1)
        self.fence_2 = Fence(fence_pose_2)

        
        # 1.5. Calculate the brick initial poses based on the table, then create the bricks
        brick_poses = [
                self.table.convert_local_position_to_global(SE3(0.3, 0.8, self.table_dimensions[2] + 0.06671/2)) @ SE3.Rz(45, 'deg'),
                self.table.convert_local_position_to_global(SE3(0.3, 0.8, self.table_dimensions[2])) @ SE3.Rz(45, 'deg'),
                self.table.convert_local_position_to_global(SE3(0.5, 0.8, self.table_dimensions[2])) @ SE3.Rz(-30, 'deg'),
                self.table.convert_local_position_to_global(SE3(0.7, 0.8, self.table_dimensions[2])) @ SE3.Rz(30, 'deg'),
                self.table.convert_local_position_to_global(SE3(0.31, 0.8, self.table_dimensions[2] + 0.06671)) @ SE3.Rz(45, 'deg'),
                self.table.convert_local_position_to_global(SE3(0.91, 1.5, self.table_dimensions[2])) @ SE3.Rz(45, 'deg'),
                self.table.convert_local_position_to_global(SE3(0.11, 1.7, self.table_dimensions[2])) @ SE3.Rz(-45, 'deg'),
                self.table.convert_local_position_to_global(SE3(0.11, 1.3, self.table_dimensions[2])) @ SE3.Rz(25, 'deg'),
                self.table.convert_local_position_to_global(SE3(0.11, 1.3, self.table_dimensions[2] + 0.06671/2)) @ SE3.Rz(45, 'deg'),
            ]
        self.bricks = [Brick(brick_poses[i]) for i in range(len(brick_poses)) ]
        brick_dimensions = self.bricks[0].get_dimensions()

        # 1.6. Create a wall scaffold to calculate the desired brick poses and maintain the state of the wall as it is built
        self.wall_scaffold = WallScaffold(self.table.convert_local_position_to_global(SE3(0.3, 2.3, self.table_dimensions[2])) @ SE3.Rz(15, 'deg'),len(self.bricks), 3, 3, brick_dimensions)
    def _setup_3d_environment(self):
        # 2. Setup the 3d swift environment
        # 2.1. Set the camera position, note: the camera look at is not respected
        camera_position = SE3(5,5,2).t
        camera_look_at = self.table.convert_local_position_to_global(SE3(self.table_dimensions[0]/2,self.table_dimensions[1]/2,self.table_dimensions[2])).t

        # 2.2. Initiate the environmnet
        self.env = swift.Swift()
        self.env.launch(realtime = True)
        self.env.set_camera_pose(camera_position, camera_look_at)

        # 2.3. Add the objects to the environment
        self.table.add_to_env(self.env)
        self.linear_ur3.add_to_env(self.env)
        self.gripper.add_to_env(self.env)
        self.estop.add_to_env(self.env)
        self.fire_extinguisher.add_to_env(self.env)
        self.fence_1.add_to_env(self.env)
        self.fence_2.add_to_env(self.env)
        for brick in self.bricks:
            brick.add_to_env(self.env)

    def plot_end_effector_volume(self):
        qlim = np.transpose(self.linear_ur3.qlim)
        points_per_joint = 5
        pointcloud_size = int((len(qlim) + 1)**points_per_joint)
        print("Generating a pointcloud of size - n=", pointcloud_size)
        pointcloud = np.zeros((pointcloud_size, 3))
        counter = 0
        start_time = time.time()
        for q0 in np.arange(qlim[0,0], qlim[0,1] + (qlim[0,1] - qlim[0,0])/points_per_joint, (qlim[0,1] - qlim[0,0])/points_per_joint):
            for q1 in np.arange(qlim[1,0], qlim[1,1] + (qlim[1,1] - qlim[1,0])/points_per_joint, (qlim[1,1] - qlim[1,0])/points_per_joint):
                for q2 in np.arange(qlim[2,0], qlim[2,1] + (qlim[2,1] - qlim[2,0])/points_per_joint, (qlim[2,1] - qlim[2,0])/points_per_joint):
                    for q3 in np.arange(qlim[3,0], qlim[3,1] + (qlim[3,1] - qlim[3,0])/points_per_joint, (qlim[3,1] - qlim[3,0])/points_per_joint):
                        for q4 in np.arange(qlim[4,0], qlim[4,1] + (qlim[4,1] - qlim[4,0])/points_per_joint, (qlim[4,1] - qlim[4,0])/points_per_joint):
                            for q5 in np.arange(qlim[5,0], qlim[5,1] + (qlim[5,1] - qlim[5,0])/points_per_joint, (qlim[5,1] - qlim[5,0])/points_per_joint):
                                q6 = 0 # q6 is the rotation of the end effector and does not affect the volume
                                q = [q0, q1, q2, q3, q4, q5, q6]
                                tr = self.linear_ur3.fkine(q).A
                                if counter == pointcloud_size:
                                    break
                                pointcloud[counter, :] = tr[0:3,3]
                                counter += 1
                                if np.mod(counter / pointcloud_size * 100, 1) == 0:
                                    end_time = time.time()
                                    execution_time = end_time - start_time
                                    print(f"After {execution_time} seconds, complete", counter/pointcloud_size*100, "% of pose")
        # Plot the point cloud in 2d looking down (i.e x-y)
        plt.figure()
        plt.plot(pointcloud[:,0], pointcloud[:,1], 'r.')
        plt.xlabel("x")
        plt.ylabel("y")
        plt.title("End effector volume in x-y plane")
        plt.show(block=False)
        input("Press Enter to continue\n")
        # Plot the point cloud in 2d looking from the side (i.e x-z)
        plt.figure()
        plt.plot(pointcloud[:,0], pointcloud[:,2], 'r.')
        plt.xlabel("x")
        plt.ylabel("z")
        plt.title("End effector volume in x-z plane")
        plt.show(block=False)
        input("Press Enter to continue\n")
        plt.close("all")
        # Plot the points
        ax = plotvol3()
        ax.plot(pointcloud[:,0], pointcloud[:,1], pointcloud[:,2], 'r')
        plt.show(block=False)
        input("Press Enter to continue\n")
        # Calculate the approximate volume of the point cloud as a rectangular prism taking the min and max of each axis
        plt.close("all")
        x_min = np.min(pointcloud[:,0])
        x_max = np.max(pointcloud[:,0])
        y_min = np.min(pointcloud[:,1])
        y_max = np.max(pointcloud[:,1])
        z_min = np.min(pointcloud[:,2])
        z_max = np.max(pointcloud[:,2])
        volume = (x_max - x_min) * (y_max - y_min) * (z_max - z_min)
        # Plot the rectangular prism on top of the point cloud
        # Plot the point cloud as points in a 3d plot
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.plot(pointcloud[:,0], pointcloud[:,1], pointcloud[:,2], 'r.')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')
        rectangular_prism_points = np.array([[x_min, y_min, z_min], [x_min, y_min, z_max], [x_min, y_max, z_min], [x_min, y_max, z_max], [x_max, y_min, z_min], [x_max, y_min, z_max], [x_max, y_max, z_min], [x_max, y_max, z_max]])
        ax.plot(rectangular_prism_points[:,0], rectangular_prism_points[:,1], rectangular_prism_points[:,2], 'b.')
        plt.show(block=False)
        print("Volume of end effector in rectangle: ", volume, " m^3")
        input("Press Enter to continue\n")
        # Now calculate the volume of the point cloud as a convex hull
        plt.close("all")
        fig = plt.figure()
        hull = ConvexHull(pointcloud)
        ax = fig.add_subplot(111, projection='3d')
        ax.plot(pointcloud[:,0], pointcloud[:,1], pointcloud[:,2], 'r.')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_zlabel('z')
        for simplex in hull.simplices:
            simplex = np.append(simplex, simplex[0])
            ax.plot(pointcloud[simplex, 0], pointcloud[simplex, 1], pointcloud[simplex, 2], 'b-')
        volume = hull.volume
        plt.show(block=False)
        print("Volume of end effector as convex hull: ", volume, " m^3")
        input("Press Enter to continue\n")
        plt.close("all")
    def run_demo(self):
        self._setup_3d_environment()
        # We want to order the bricks by their height off the table to minimise risk of collision i.e. pickup the highest bricks first
        self.bricks.sort(key= lambda brick: brick.T[2,3], reverse=True)

        safe_operating_offset = SE3(0, 0, 0.2)
        end_effector_to_brick_offset = SE3(0, 0, 0.1)

        for brick in self.bricks:
            # Steps:
            # 1. Go above the brick pointing down (approx. 30cm above)
            # 2. Go down to the brick (approx. 10cm above)
            # 3. Close the gripper and pickup the brick
            # 4. Raise the brick above the table (approx. 30cm above)
            # 5. Go above the desired brick position pointing down (approx. 30cm above)
            # 6. Go down to the desired brick position (approx. 10cm above)
            # 7. Release the brick
            brick_pose = SE3(brick.T)

            # Step 1.
            # The desired pose is the brick pose, with the safe operating offset and the gripper pointing down
            desired_pose = brick_pose @ safe_operating_offset @ SE3.Rx(180, 'deg') # We want to be above the brick with the gripper pointing down
            q_goal = self.linear_ur3.ikine_LM(desired_pose, q0=self.linear_ur3.q, joint_limits=True)
            if q_goal.success == False:
                print("Failed to find a solution to get above the brick, increasing search limit")
                q_goal = self.linear_ur3.ikine_LM(desired_pose, q0=self.linear_ur3.q, slimit=400, joint_limits=True)
                if q_goal.success == False:
                    print("Failed to find a solution to get to brick even with increased search limit. Skipping this brick.")
                    continue
            
            # Calculate the forward kinematics to determine offset to desired pose
            expected_end_effector_pose = self.linear_ur3.fkine(q_goal.q)
            print("Found solution to get above brick: " + str(q_goal.q))
            print("Solution offsets - x: " + str(expected_end_effector_pose.t[0] - desired_pose.t[0]) + ", y: " + str(expected_end_effector_pose.t[1] - desired_pose.t[1]) + ", z: " + str(expected_end_effector_pose.t[2] - desired_pose.t[2]))

            steps = 50
            s = rtb.trapezoidal(0,1,steps).q
            q_matrix = np.zeros([steps,self.linear_ur3.n])
            for i in range(steps):
                q_matrix[i,:] =  (1 - s[i]) * self.linear_ur3.q + s[i]*q_goal.q

            for q in q_matrix:
                self.linear_ur3.set_q(q)
                self.env.step(0.02)
            
            # Step 2.
            # We can now exceed the safe operating offset and go down to pickup the brick
            desired_pose = brick_pose @ end_effector_to_brick_offset @ SE3.Rx(180, 'deg') # We want to be above the brick with the gripper pointing down
            q_goal = self.linear_ur3.ikine_LM(desired_pose, q0=self.linear_ur3.q, joint_limits=True)
            if q_goal.success == False:
                print("Failed to find a solution to get to brick")
                continue

            # Calculate the forward kinematics to determine distance to desired pose
            expected_end_effector_pose = self.linear_ur3.fkine(q_goal.q)
            print("Found solution to get to brick: " + str(q_goal.q))
            print("Solution offsets - x: " + str(expected_end_effector_pose.t[0] - desired_pose.t[0]) + ", y: " + str(expected_end_effector_pose.t[1] - desired_pose.t[1]) + ", z: " + str(expected_end_effector_pose.t[2] - desired_pose.t[2]))

            steps = 50
            s = rtb.trapezoidal(0,1,steps).q
            q_matrix = np.zeros([steps,self.linear_ur3.n])
            for i in range(steps):
                q_matrix[i,:] =  (1 - s[i]) * self.linear_ur3.q + s[i]*q_goal.q

            for q in q_matrix:
                self.linear_ur3.set_q(q)
                self.env.step(0.02)
        
            # Step 3.
            # We are now at the brick, so we can close the gripper and pickup the brick
            self.gripper.animate_close(self.env)
            self.gripper.pickup_brick(brick)

            # Step 4.
            # We now want to raise the brick so we are operating within the safe zone
            current_end_effector_pose = self.linear_ur3.fkine(self.linear_ur3.q)
            print("current end effector x: ", current_end_effector_pose.t[0], " y: ", current_end_effector_pose.t[1], " z: ", current_end_effector_pose.t[2])
            desired_pose = brick_pose @ safe_operating_offset @ SE3.Rx(180, 'deg')
            print("desired end effector x: ", desired_pose.t[0], " y: ", desired_pose.t[1], " z: ", desired_pose.t[2])
            q_goal = self.linear_ur3.ikine_LM(desired_pose, q0=self.linear_ur3.q, joint_limits=True)

            if q_goal.success == False:
                print("Failed to find a solution to raise brick to safe operating zone")
                continue

            # Calculate the forward kinematics to determine distance to desired pose
            expected_end_effector_pose = self.linear_ur3.fkine(q_goal.q)
            print("Found solution to raise brick to safe operating zone: " + str(q_goal.q))
            print("Solution offsets - x: " + str(expected_end_effector_pose.t[0] - desired_pose.t[0]) + ", y: " + str(expected_end_effector_pose.t[1] - desired_pose.t[1]) + ", z: " + str(expected_end_effector_pose.t[2] - desired_pose.t[2]))

            steps = 50
            s = rtb.trapezoidal(0,1,steps).q
            q_matrix = np.zeros([steps,self.linear_ur3.n])
            for i in range(steps):
                q_matrix[i,:] =  (1 - s[i]) * self.linear_ur3.q + s[i]*q_goal.q

            for q in q_matrix:
                self.linear_ur3.set_q(q)
                self.env.step(0.02)
            
            # Step 5.
            # We now want to go to the desired brick position + the safe operating offset with the gripper pointing down
            desired_pose = self.wall_scaffold.get_next_brick_pose() @ safe_operating_offset @ SE3.Rx(180, 'deg')

            q_goal = self.linear_ur3.ikine_LM(desired_pose, q0=self.linear_ur3.q, joint_limits=True)

            if q_goal.success == False:
                print("Failed to find a solution to return brick to home")
                continue

            # Calculate the forward kinematics to determine distance to desired pose
            expected_end_effector_pose = self.linear_ur3.fkine(q_goal.q)
            print("Found solution to raise brick to safe operating zone: " + str(q_goal.q))
            print("Solution offsets - x: " + str(expected_end_effector_pose.t[0] - desired_pose.t[0]) + ", y: " + str(expected_end_effector_pose.t[1] - desired_pose.t[1]) + ", z: " + str(expected_end_effector_pose.t[2] - desired_pose.t[2]))

            steps = 50
            s = rtb.trapezoidal(0,1,steps).q
            q_matrix = np.zeros([steps,self.linear_ur3.n])
            for i in range(steps):
                q_matrix[i,:] =  (1 - s[i]) * self.linear_ur3.q + s[i]*q_goal.q

            for q in q_matrix:
                self.linear_ur3.set_q(q)
                self.env.step(0.02)

            # Step 6.
            # We now want to go down to the desired brick position with the gripper pointing down
            desired_pose = self.wall_scaffold.get_next_brick_pose() @ end_effector_to_brick_offset @ SE3.Rx(180, 'deg')

            q_goal = self.linear_ur3.ikine_LM(desired_pose, q0=self.linear_ur3.q, joint_limits=True)

            if q_goal.success == False:
                print("Failed to find a solution to return brick to home")
                continue

            # Calculate the forward kinematics to determine distance to desired pose
            expected_end_effector_pose = self.linear_ur3.fkine(q_goal.q)
            print("Found solution to raise brick to safe operating zone: " + str(q_goal.q))
            print("Solution offsets - x: " + str(expected_end_effector_pose.t[0] - desired_pose.t[0]) + ", y: " + str(expected_end_effector_pose.t[1] - desired_pose.t[1]) + ", z: " + str(expected_end_effector_pose.t[2] - desired_pose.t[2]))

            steps = 50
            s = rtb.trapezoidal(0,1,steps).q
            q_matrix = np.zeros([steps,self.linear_ur3.n])
            for i in range(steps):
                q_matrix[i,:] =  (1 - s[i]) * self.linear_ur3.q + s[i]*q_goal.q

            for q in q_matrix:
                self.linear_ur3.set_q(q)
                self.env.step(0.02)
            
            # Step 7.
            # We now want to release the brick
            self.gripper.animate_open(self.env)
            self.gripper.release_brick()
            self.wall_scaffold.add_brick_to_wall(brick)

        # Finally return all joint states to 0
        q_goal = np.array([0,0,-pi/2,0,0,0,0])
        steps = 50
        s = rtb.trapezoidal(0,1,steps).q
        q_matrix = np.zeros([steps,self.linear_ur3.n])
        for i in range(steps):
            q_matrix[i,:] =  (1 - s[i]) * self.linear_ur3.q + s[i]*q_goal

        for q in q_matrix:
            self.linear_ur3.set_q(q)
            self.env.step(0.02)
        input("Press Enter to exit\n")
        self.env.close()

if __name__ == "__main__":
    assignment1 = Assignment1()
    assignment1.plot_end_effector_volume()
    assignment1.run_demo()