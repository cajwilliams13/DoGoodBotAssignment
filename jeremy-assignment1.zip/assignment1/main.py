from Assignment1 import Assignment1

if __name__ == '__main__':
    assignment1 = Assignment1()
    # assignment1.plot_end_effector_volume()
    assignment1.run_demo()