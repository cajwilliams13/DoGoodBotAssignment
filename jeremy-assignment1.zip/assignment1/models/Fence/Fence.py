import os

import spatialgeometry as geometry
from spatialmath import SE3


class Fence(geometry.Mesh):
    def __init__(self, initial_pose=SE3(0, 0, 0)):
        full_path = os.path.realpath(__file__)
        directory = os.path.dirname(full_path)
        fence_stl = os.path.join(directory, 'Fence.stl')
        super().__init__(fence_stl, pose=initial_pose, color=(0.5, 0.5, 0.5, 1))
    def add_to_env(self, env):
        env.add(self)