import os

import spatialgeometry as geometry
from spatialmath import SE3


class Brick(geometry.Mesh):
    def __init__(self, initial_pose=SE3(0, 0, 0)):
        full_path = os.path.realpath(__file__)
        directory = os.path.dirname(full_path)
        brick_stl = os.path.join(directory, 'Brick.stl')
        self._dimensions = (0.06671, 0.13343, 0.06671/2)
        super().__init__(brick_stl, pose=initial_pose, color=(0.5, 0, 0, 1))
    def add_to_env(self, env):
        env.add(self)
    def get_dimensions(self):
        return self._dimensions