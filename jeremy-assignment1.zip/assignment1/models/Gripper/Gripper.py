##  @file
#   @brief A 3D Robot Class defined by standard DH parameters.
#   @author Ho Minh Quang Ngo
#   @date Jul 20, 2023

import os
from abc import ABC
# Useful variables
from math import pi

import numpy as np
import roboticstoolbox as rtb
import spatialgeometry as geometry
import spatialmath.base as spb
import swift
from models.Gripper.Finger import Finger
from spatialmath import SE3


class Gripper():
    def __init__(self):
        self._base = SE3(0,0,0)
        self.brick = None

        self.finger1 = Finger()
        self.finger2 = Finger()

        current_directory = os.path.abspath(os.path.dirname(__file__))
        self.base_3d = geometry.Mesh(os.path.join(current_directory, 'gripper_base.stl'))
        self.base_3d.T = self.base.A

        self.finger1_offset = SE3(0.01,0.04,0.03) @ SE3.Rz(pi/2)
        self.finger2_offset = SE3(0.05,0.04,0.03) @ SE3.Rz(pi/2) @ SE3.Rx(pi)

        self.finger1.base = self._base * self.finger1_offset
        self.finger2.base = self._base * self.finger2_offset
    
    def add_to_env(self, env):
        env.add(self.base_3d)
        self.finger1.add_to_env(env)
        self.finger2.add_to_env(env)

    def open_fingers(self):
        # Open
        self.finger1.q = [pi/4, -pi/4]
        self.finger2.q = [pi/4, -pi/4]
    
    def close_fingers(self):
        # Close
        self.finger1.q = [0, 0]
        self.finger2.q = [0, 0]

    def animate_close(self, env):
        # Close is finger 1 going from [pi/4, -pi/4] to [0, 0]
        # and finger 2 going from [-pi/4, pi/4] to [0, 0]
        steps = 50
        finger1_q = np.linspace([pi/4, -pi/4], [0, 0], steps)
        finger2_q = np.linspace([pi/4, -pi/4], [0, 0], steps)
        for i in range(steps):
            self.finger1.q = finger1_q[i]
            self.finger2.q = finger2_q[i]
            env.step(0.02)
    
    def animate_open(self, env):
        steps = 50
        finger1_q = np.linspace([0, 0], [pi/4, -pi/4], steps)
        finger2_q = np.linspace([0, 0], [pi/4, -pi/4], steps)
        for i in range(steps):
            self.finger1.q = finger1_q[i]
            self.finger2.q = finger2_q[i]
            env.step(0.02)
    
    def pickup_brick(self, brick):
        self.brick = brick
        # Now find the offset between the base of the gripper and the brick
        brick_pose = SE3(brick.T)
        gripper_base_pose = self._base
        # We want to find the coordinates of the brick in the gripper base frame
        print("gripper base pose: x = " + str(gripper_base_pose.t[0]) + ", y = " + str(gripper_base_pose.t[1]) + ", z = " + str(gripper_base_pose.t[2]))
        print("brick pose: x = " + str(brick_pose.t[0]) + ", y = " + str(brick_pose.t[1]) + ", z = " + str(brick_pose.t[2]))
        self.brick_offset = gripper_base_pose.inv() @ brick_pose
        print("brick offset: x = " + str(self.brick_offset.t[0]) + ", y = " + str(self.brick_offset.t[1]) + ", z = " + str(self.brick_offset.t[2]))
        return brick
    
    def release_brick(self):
        self.brick = None
        self.brick_offset = None
        return None
    
    @property
    def base(self):
        return self._base
    
    @base.setter
    def base(self, value):
        self._base = value
        self.finger1.base = self._base * self.finger1_offset
        self.finger2.base = self._base * self.finger2_offset
        self.base_3d.T = self._base.A
        if self.brick is not None:
            self.brick.T = self.base @ self.brick_offset


