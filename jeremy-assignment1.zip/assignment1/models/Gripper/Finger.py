##  @file
#   @brief A 3D Robot Class defined by standard DH parameters.
#   @author Ho Minh Quang Ngo
#   @date Jul 20, 2023

import os
from abc import ABC
# Useful variables
from math import pi

import numpy as np
import roboticstoolbox as rtb
import spatialgeometry as geometry
import spatialmath.base as spb
import swift
from spatialmath import SE3


class Finger(rtb.DHRobot):
    def __init__(self):
        links = [
                    rtb.RevoluteDH(d=0, a=0.035, alpha=0, qlim= [-2*pi, 2*pi]), # Finger 1
                    rtb.RevoluteDH(d=0, a=0.035, alpha=0, qlim= [-2*pi, 2*pi]), # Finger 1
                ]
        super().__init__(links, name="Finger")
        self._qtest = [0, 0]
        self._qtest_transforms = [
            spb.transl(0,0,0),
            # spb.transl(0,0.005,-0.023/2)@ spb.rpy2tr(pi/2,pi,pi, order = 'xyz'),
            # spb.transl(0.035,0.005,-0.023/2)@ spb.rpy2tr(pi/2,pi,pi, order = 'xyz'),
            spb.transl(0,0.005,-0.023/2)@ spb.rpy2tr(pi/2,pi,pi, order = 'xyz'),
            spb.transl(0.035,-0.0145,0.0127)@ spb.rpy2tr(pi/2,pi,0, order = 'xyz'),
        ]
        self._apply_3dmodel()
        self.q = self._qtest
    
    def _apply_3dmodel(self):
        # We want to add the base Mesh, as well as a mesh for each link
        current_directory = os.path.abspath(os.path.dirname(__file__))

        self.links_3d = [
                            None,
                            geometry.Mesh(os.path.join(current_directory, 'gripper_finger_link1_35mm.stl')),
                            geometry.Mesh(os.path.join(current_directory, 'gripper_finger_link2_35mm.stl'))
                        ]

        
        link_transforms = self._get_transforms(self._qtest)

        # Get relation matrix between the pose of the DH Link and the pose of the corresponding 3d object
        self._relation_matrices = [np.linalg.inv(link_transforms[i]) @ self._qtest_transforms[i] 
                                   for i in range(len(link_transforms))] 
    
    def _get_transforms(self,q):
        """
        Get the transform list represent each link
        """
        transforms = [self.base.A]
        L = self.links
        for i in range(self.n):
            previous_joint_transform = transforms[i]
            joint = L[i]
            joint_q = q[i]
            previous_to_current = joint.A(joint_q)
            # Print current link to next x,y,z
            # print("current link to next x: ", previous_to_current.A[0,3])
            # print("current link to next y: ", previous_to_current.A[1,3])
            # print("current link to next z: ", previous_to_current.A[2,3])

            transform = previous_joint_transform @ previous_to_current.A
            transforms.append(transform)
        return transforms
    
    def _update_3dmodel(self):
        link_transforms = self._get_transforms(self.q)
        for i, link in enumerate(self.links_3d):
            if link is not None:
                link.T = link_transforms[i] @ self._relation_matrices[i]

    def add_to_env(self, env):
        """
        Add the robot into a input Swift environment
        """
        if not isinstance(env, swift.Swift):
            raise TypeError('Environment must be Swift!')
        self._update_3dmodel()
        for link in self.links_3d:
            if link is not None:
                env.add(link)
    
    def set_q(self, q):
        """
        Set the joint angles of the robot
        """
        self.q = q
        self._update_3dmodel()
    
    def __setattr__(self, name, value):
        """
        Overload `=` operator so the object can update its 3D model whenever a new joint state is assigned
        """
        if name == 'q' and hasattr(self, 'q'):
            self._update_3dmodel()  # Update the 3D model before setting the attribute
        elif name == 'base' and hasattr(self, 'base'):
            self._update_3dmodel()
        super().__setattr__(name, value)  # Call the base class method to set the attribute