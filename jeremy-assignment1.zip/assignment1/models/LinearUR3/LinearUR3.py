##  @file
#   @brief UR5 Robot on a Linear rail defined by standard DH parameters with 3D model
#   @author Ho Minh Quang Ngo
#   @date Jul 20, 2023

import os
import time
# Useful variables
from math import pi

import roboticstoolbox as rtb
import spatialmath.base as spb
import swift
from ir_support.robots.DHRobot3D import DHRobot3D
from spatialmath import SE3


# -----------------------------------------------------------------------------------#
class LinearUR3(DHRobot3D):
    """ 
    UR3 Robot on a Linear Rail.
    Customised from LinearUR5 and UR3 models provided in the ir_support package

    """     
    def __init__(self, initial_pose=SE3(0, 0, 0)):         
        # DH links
        links = self._create_DH()     
        
        # Names of the robot link files in the directory
        link3D_names = dict(link0 = 'base_rail', color0 = (0.2,0.2,0.2,1),      # color option only takes effect for stl file
                            link1 = 'slider_rail', color1 = (0.1,0.1,0.1,1),
                            link2 = 'shoulder_ur3', 
                            link3 = 'upperarm_ur3',
                            link4 = 'forearm_ur3',
                            link5 = 'wrist1_ur3',
                            link6 = 'wrist2_ur3',
                            link7 = 'wrist3_ur3')
        
        # A joint config and the 3D object transforms to match that config
        qtest = [0,0,-pi/2,0,0,0,0] #ORIGINAL
        # qtest = [0, 0, -pi/2, 0, -pi, pi, 0]
        # rpy2tr(⍺, β, γ)
        # 'xyz', rotate by γ about the x-axis, then by β about the new y-axis, then by ⍺ about the new z-axis. 
        # Convention for a robot gripper with z-axis forward and y-axis between the gripper fingers
        # Shoulder ⍺ = 0, β = pi, γ = pi/2 i.e. rotate by pi/2 about the y-axis and then by pi about the new z-axis
        qtest_transforms = [spb.transl(0,0,0), # base
                            spb.trotx(-pi/2), # slider
                            spb.transl(0,0.15712,0) @ spb.rpy2tr(pi,pi,pi/2, order='xyz'), # shoulder_new new 2
                            spb.transl(0,0.15756,-0.12)@ spb.rpy2tr(pi,pi,pi/2, order='xyz'), # upperarm_new new 2
                            spb.transl(0,0.401,-0.025) @ spb.rpy2tr(pi,pi,pi/2, order='xyz'), # forearm_new new 2
                            spb.transl(0,0.614,-0.024) @ spb.rpy2tr(pi ,pi/2,pi/2, order = 'xyz'), # wrist1_new new 2
                            spb.transl(0,0.614,-0.11) @ spb.rpy2tr(pi,pi/2,pi/2, order = 'xyz'), # wrist2_new
                            spb.transl(0.0835,0.616,-0.11) @ spb.rpy2tr(0,0,-pi/2, order = 'xyz')] # wrist3_new
        
        current_path = os.path.abspath(os.path.dirname(__file__))
        super().__init__(links, link3D_names, name = 'LinearUR3', link3d_dir = current_path, qtest = qtest, qtest_transforms = qtest_transforms)
        self.base = self.base * initial_pose * SE3.Rx(pi/2) * SE3.Ry(pi/2)
        self.q = qtest
        self.gripper = None
        
    # -----------------------------------------------------------------------------------#    
    def _create_DH(self):
        """
        Create robot's standard DH model
        """
        links = [rtb.PrismaticDH(theta= pi, a= 0, alpha= pi/2, qlim= [-0.8, 0])]    # Prismatic Link
        a = [0, -0.24365, -0.21325, 0, 0, 0]
        d = [0.1519, 0, 0, 0.11235, 0.08535, 0.0819]
        alpha = [pi/2, 0, 0, pi/2, -pi/2, 0]
        qlim = [[-2*pi, 2*pi] for _ in range(6)]
        qlim[1]= [-pi, 0] # Set the upperarm q limits so it can't
        for i in range(6):
            link = rtb.RevoluteDH(d=d[i], a=a[i], alpha=alpha[i], qlim= qlim[i])
            links.append(link)
        return links
                    
    # -----------------------------------------------------------------------------------#
    def test(self):
        """
        Test the class by adding 3d objects into a new Swift window and do a simple movement
        """
        env = swift.Swift()
        env.launch(realtime= True)
        self.q = self._qtest        
        self.add_to_env(env)
        q_goal = [self.q[i]-pi/3 for i in range(self.n)]
        q_goal[0] = -0.8 # Move the rail link
        qtraj = rtb.jtraj(self.q, q_goal, 50).q
        # fig = self.plot(self.q, limits= [-1,1,-1,1,-1,1])
        # fig._add_teach_panel(self, self.q)
        for q in qtraj:
            self.q = q
            env.step(0.02)
            # fig.step(0.01)
        # fig.hold()
        env.hold()
        time.sleep(3)
    
    def set_q(self, q):
        self.q = q

        if self.gripper is not None:
            end_effector = self.fkine(q)
            self.gripper.base = end_effector @ SE3(-0.04,0.03,0) @ SE3.Rx(pi/2)
            # self.gripper.q = self.gripper.q
        return q

    def attach_gripper(self, gripper):
        """
        Attach a gripper to the end-effector of the robot
        """
        q = self.q
        gripper.base = self.fkine(q) @ SE3(-0.035,0.033,-0.01) @ SE3.Rx(pi/2)
        self.gripper = gripper
        return gripper

    def detach_gripper(self):
        """
        Detach the gripper from the robot
        """
        self.gripper = None
        return None

# ---------------------------------------------------------------------------------------#
if __name__ == "__main__":  
    r = LinearUR3()
    r.test()
    

    