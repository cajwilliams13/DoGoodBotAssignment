import os

import spatialgeometry as geometry
from spatialmath import SE3


class Table(geometry.Mesh):
    def __init__(self, initial_pose=SE3(0, 0, 0)):
        full_path = os.path.realpath(__file__)
        directory = os.path.dirname(full_path)
        brick_stl = os.path.join(directory, 'Table.stl')
        offset = SE3.Rx(90, 'deg') @ SE3.Ry(90, 'deg')
        # _dimensions are x, y, z => x width, y length, z height
        self._dimensions = (1, 2.5, 0.85)
        pose = initial_pose @ offset
        super().__init__(brick_stl, pose=pose, color=(0, 0, 0.5, 1))
    def add_to_env(self, env):
        env.add(self)
    def get_dimensions(self):
        return self._dimensions
    def convert_local_position_to_global(self, local_position):
        table_pose_no_rotation = SE3.Trans(self.T[0,3], self.T[1,3], self.T[2,3])
        return table_pose_no_rotation * local_position
