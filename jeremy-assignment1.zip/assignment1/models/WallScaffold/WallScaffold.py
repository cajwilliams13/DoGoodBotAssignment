from spatialmath import SE3


class WallScaffold():
    def __init__(self, wall_reference_frame, total_number_of_bricks, desired_rows, desired_columns, brick_dimensions):
        self.wall_reference_frame = wall_reference_frame
        self.total_number_of_bricks = total_number_of_bricks
        self.desired_rows = desired_rows
        self.desired_columns = desired_columns
        self.brick_dimensions = brick_dimensions
        self.wall_brick_poses = self._generate_wall_brick_poses()
        self.bricks_in_wall = []

    def _generate_wall_brick_poses(self):
        poses = []
        current_brick = 0
        for row in range(self.desired_rows):
            for column in range(self.desired_columns):
                if current_brick >= self.total_number_of_bricks:
                    break
                poses.append(self.wall_reference_frame @ SE3(column*self.brick_dimensions[1], 0, row*self.brick_dimensions[2]) @ SE3.Rz(90, 'deg'))
                current_brick += 1
            else:
                continue
            break
        return poses
    
    def add_brick_to_wall(self, brick):
        self.bricks_in_wall.append(brick)
    
    def get_next_brick_pose(self):
        return self.wall_brick_poses[len(self.bricks_in_wall)]