import os

import spatialgeometry as geometry
from spatialmath import SE3


class FireExtinguisher(geometry.Mesh):
    def __init__(self, initial_pose=SE3(0, 0, 0)):
        full_path = os.path.realpath(__file__)
        directory = os.path.dirname(full_path)
        fire_extinguisher_stl = os.path.join(directory, 'FireExtinguisher.stl')
        super().__init__(fire_extinguisher_stl, pose=initial_pose, color=(0.5, 0.5, 0, 1))
    def add_to_env(self, env):
        env.add(self)